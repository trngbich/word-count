

Usage
=====


How to clone the code
---------------------

Write me ...


Make
----

Generate all results:

::

  $ make


Snakemake
---------

Write me ...


Where to find the results
-------------------------

Write me ...
