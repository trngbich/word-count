.. this is a comment, it is not rendered
   when adding new *.rst files, reference them here
   in this index.rst for them to be rendered and added to the
   table of contents


word-count
==========

.. toctree::
   :maxdepth: 2

   purpose.rst
   dependencies.rst
   usage.rst
   credit.rst
   exercises.rst
